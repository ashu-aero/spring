package com.nms;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StatusReport {

	@Autowired
	private StatusRepository statusRepo;

	public void generateExcel(HttpServletResponse response) throws Exception {

		List<Status> statusList = statusRepo.findAll();

		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("Courses Info");
		HSSFRow row = sheet.createRow(0);

		row.createCell(0).setCellValue("id");
		row.createCell(1).setCellValue("dtimestamp");
		row.createCell(2).setCellValue("utimestamp");
		row.createCell(3).setCellValue("ip_address");

		int dataRowIndex = 1;

		for (Status status : statusList) {
			HSSFRow dataRow = sheet.createRow(dataRowIndex);
			dataRow.createCell(0).setCellValue(status.getId());
			dataRow.createCell(1).setCellValue(status.getIp_address());
			dataRow.createCell(2).setCellValue(status.getDtimestamp());
			dataRow.createCell(3).setCellValue(status.getUtimestamp());
			dataRow.createCell(4).setCellValue(status.getIp_address());
			dataRowIndex++;
		}

		ServletOutputStream ops = response.getOutputStream();
		workbook.write(ops);
		workbook.close();
		ops.close();

	}

}