package com.nms;

public class MyConstant {
	
	public static final String COMPANY_NAME="Here Mera Company Name";

}
